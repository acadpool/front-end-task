//search bar using Js
document.querySelector(".search-button").addEventListener("click",()=>{
	document.querySelector("input").classList.toggle('change');
});
//nav-bar using jquery

$(window).on("scroll",()=>{
	if($(window).scrollTop()){
		$("nav").addClass('navbar-change');
	}
	else{
		$('nav').removeClass('navbar-change');
	}

});
//slider using js
var i = 0;
var img = [];
var time = 3000;
img[0] = './image/menswear.png';
img[1] = './image/women.png';
img[2] = './image/kids.png';
function change(){
	document.slide.src = img[i];
	if(i < img.length -1 ){
		i++;

	}
	else{
		i=0;
	}
	setTimeout("change()",time);
}


window.onload = change;

//uncomplete
const button = document.querySelector(".button");
	button.addEventListener("click",func);
	function func(){
		alert("Not completed !");
	}
const signin = document.querySelector(".color1");
	signin.addEventListener("click",func);
	function func(){
		alert("Not completed !");
	}
